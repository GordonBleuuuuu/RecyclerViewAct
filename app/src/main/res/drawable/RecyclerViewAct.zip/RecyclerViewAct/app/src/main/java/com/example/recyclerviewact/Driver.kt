package com.example.f1drivers

data class Driver(val name: String, val team: String, val imageResId: Int)